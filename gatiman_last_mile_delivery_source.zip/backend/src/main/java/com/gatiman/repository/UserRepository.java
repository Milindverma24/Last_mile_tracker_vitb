package com.gatiman.repository;

import com.gatiman.entity.User;
import com.gatiman.enums.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    Optional<User> findByUuid(String uuid);
    Boolean existsByEmail(String email);
    List<User> findByRole(Role role);
}
