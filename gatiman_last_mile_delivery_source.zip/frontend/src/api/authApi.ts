import { apiClient } from './axios';
import { ApiResponse, AuthResponse, User } from '../types';

export interface LoginPayload {
  email: string;
  password: string;
}

export interface RegisterPayload {
  email: string;
  password: string;
  firstName: string;
  lastName?: string;
  phoneNumber?: string;
  address?: string;
  city?: string;
  state?: string;
  pinCode?: string;
  role?: string;
  customerType?: string;
  companyName?: string;
  gstNumber?: string;
  vehicleType?: string;
  vehicleNumber?: string;
  assignedZoneId?: number;
}

export interface GoogleAuthPayload {
  credential: string;
  customerType?: 'B2C' | 'B2B';
  companyName?: string;
  gstNumber?: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  pictureUrl?: string;
  phoneNumber?: string;
  address?: string;
  city?: string;
  state?: string;
  pinCode?: string;
}

export const authApi = {
  login: async (payload: LoginPayload): Promise<AuthResponse> => {
    const res = await apiClient.post<ApiResponse<AuthResponse>>('/auth/login', payload);
    return res.data.data;
  },

  register: async (payload: RegisterPayload): Promise<AuthResponse> => {
    const res = await apiClient.post<ApiResponse<AuthResponse>>('/auth/register', payload);
    return res.data.data;
  },

  googleLogin: async (payload: GoogleAuthPayload): Promise<AuthResponse> => {
    const res = await apiClient.post<ApiResponse<AuthResponse>>('/auth/google', payload);
    return res.data.data;
  },

  getCurrentUser: async (): Promise<User> => {
    const res = await apiClient.get<ApiResponse<User>>('/auth/me');
    return res.data.data;
  },
};
